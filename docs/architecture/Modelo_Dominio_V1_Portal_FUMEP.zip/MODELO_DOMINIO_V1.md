# MODELO DE DOMÍNIO V1 — PORTAL FUMEP

## 1. Institution
Representa cada instituição atendida pelo portal.

Exemplos:
- FUMEP
- ETMSL
- CRAMAM

Campos:
- id
- name
- slug
- shortName
- description
- logoLight
- logoDark
- primaryColor
- secondaryColor
- accentColor
- isActive
- createdAt
- updatedAt

Exemplos de URLs:
- /
- /etmsl
- /cramam

FUMEP é a instituição principal.

## 2. User
Usuário do painel administrativo.

Campos:
- id
- name
- email
- passwordHash
- role
- isActive
- lastLoginAt
- createdAt
- updatedAt

Papéis:
- ADMIN
- EDITOR

### UserInstitution
Permite que um Editor administre uma ou várias instituições.

Campos:
- userId
- institutionId

## 3. Page
Representa páginas institucionais construídas através do Page Builder.

Campos:
- id
- institutionId
- title
- slug
- description
- status
- isHome
- seoTitle
- seoDescription
- seoImageId
- publishedAt
- scheduledAt
- expiresAt
- createdBy
- updatedBy
- publishedBy
- createdAt
- updatedAt

Status:
- DRAFT
- SCHEDULED
- PUBLISHED
- EXPIRED

## 4. PageVersion
Histórico das páginas.

Campos:
- id
- pageId
- versionNumber
- snapshot
- createdBy
- createdAt

## 5. PageBlock
Coração do construtor visual por blocos.

Campos:
- id
- pageId
- type
- position
- anchor
- isVisible
- backgroundStyle
- configuration
- createdAt
- updatedAt

Ações permitidas:
- reordenar
- duplicar
- ocultar
- excluir
- configurar

## 6. BlockType
Tipos V1:
- TEXT
- HERO
- IMAGE
- IMAGE_TEXT
- CAROUSEL
- CARDS
- QUICK_LINKS
- FAQ
- TABS
- TABLE
- TIMELINE
- STATISTICS
- MAP
- VIDEO
- DOCUMENT
- NEWS_FEED
- EVENT_FEED
- COURSE_FEED
- CONTEST_FEED
- SELECTION_PROCESS_FEED
- GALLERY_FEED
- CTA
- SPACER

## 7. PageTemplate
Modelos reutilizáveis de páginas.

Campos:
- id
- name
- description
- institutionId?
- blocksSnapshot
- createdBy
- isActive
- createdAt
- updatedAt

## 8. Article
Representa notícias, comunicados e matérias.

Campos:
- id
- title
- subtitle?
- summary?
- content
- coverImageId
- coverImageAlt
- publicAuthor?
- status
- isFeatured
- publishedAt
- scheduledAt?
- expiresAt?
- seoTitle?
- seoDescription?
- createdBy
- updatedBy
- publishedBy
- createdAt
- updatedAt

Obrigatórios mínimos:
- title
- content
- coverImage
- coverImageAlt
- institution
- status

## 9. ArticleInstitution
Permite que uma notícia pertença a várias instituições.

Campos:
- articleId
- institutionId

## 10. ArticleVersion
Histórico das notícias.

Campos:
- id
- articleId
- versionNumber
- snapshot
- createdBy
- createdAt

## 11. Category
Campos:
- id
- institutionId?
- name
- slug
- description?
- type?
- createdBy
- createdAt
- updatedAt

Pode ser global ou específica de uma instituição.

## 12. Tag
Campos:
- id
- name
- slug
- createdBy
- createdAt

## 13. ArticleCategory
Campos:
- articleId
- categoryId

## 14. ArticleTag
Campos:
- articleId
- tagId

## 15. Course
Cursos são entidades próprias.

Campos:
- id
- institutionId
- name
- slug
- shortDescription
- fullDescription
- requirements?
- professionalProfile?
- jobMarket?
- coordinator?
- status
- coverImageId?
- createdBy
- updatedBy
- createdAt
- updatedAt

Status:
- ACTIVE
- TEMPORARILY_UNAVAILABLE
- CLOSED

Cursos CLOSED não aparecem no portal público.

## 16. CourseOffering
Permite várias modalidades, turnos e durações por curso.

Campos:
- id
- courseId
- modality
- shift
- duration
- workloadHours
- isActive
- createdAt
- updatedAt

## 17. CourseCurriculum
Matriz curricular em PDF.

Campos:
- id
- courseId
- mediaId
- title
- validFrom?
- validUntil?
- createdAt

## 18. CourseImage
Campos:
- courseId
- mediaId
- position
- altText

## 19. CourseDocument
Campos:
- id
- courseId
- mediaId
- title
- description?
- position
- createdAt

## 20. Event
Campos:
- id
- title
- slug
- shortDescription?
- fullDescription?
- coverImageId?
- coverImageAlt?
- address?
- latitude?
- longitude?
- externalRegistrationUrl?
- status
- startsAt
- endsAt
- createdBy
- updatedBy
- publishedAt?
- createdAt
- updatedAt

## 21. EventInstitution
Campos:
- eventId
- institutionId

## 22. EventSchedule
Permite eventos com vários dias e horários.

Campos:
- id
- eventId
- title
- description?
- date
- startTime
- endTime?
- location?
- position

## 23. EventCategory
Campos:
- eventId
- categoryId

## 24. Gallery
Campos:
- id
- institutionId?
- title
- description?
- createdBy
- createdAt
- updatedAt

## 25. GalleryItem
Campos:
- id
- galleryId
- mediaId
- caption?
- altText
- position

## 26. Media
Biblioteca central de mídia.

Campos:
- id
- type
- originalFilename
- storedFilename
- mimeType
- sizeBytes
- width?
- height?
- altText?
- caption?
- categoryId?
- uploadedBy
- createdAt

Tipos:
- IMAGE
- DOCUMENT
- VIDEO
- OTHER

## 27. MediaVariant
Versões otimizadas.

Campos:
- id
- mediaId
- format
- width?
- height?
- sizeBytes
- path

Exemplos:
- original.jpg
- 640.webp
- 1280.webp
- 640.avif
- 1280.avif

## 28. MediaCategory
Campos:
- id
- name
- slug
- institutionId?
- createdBy
- createdAt

## 29. MediaUsage
Rastreia onde uma mídia está sendo usada.

Campos:
- mediaId
- entityType
- entityId
- field

Regra:
- mídia em uso não pode ser excluída.

## 30. InternshipArea
Área de estágio.

Campos:
- id
- institutionId
- title
- description
- createdAt
- updatedAt

## 31. InternshipCategory
Exemplos:
- Orientações
- Formulários
- Relatórios
- Legislação
- Documentos por curso

Campos:
- id
- internshipAreaId
- name
- description?
- position

## 32. InternshipDocument
Campos:
- id
- categoryId
- courseId?
- mediaId
- title
- description?
- position
- createdAt
- updatedAt

## 33. Menu
Apenas Administrador altera menus.

Campos:
- id
- institutionId
- name
- location
- createdAt
- updatedAt

Locations:
- HEADER
- FOOTER

## 34. MenuItem
Campos:
- id
- menuId
- parentId?
- label
- type
- pageId?
- url?
- position
- isVisible
- openInNewTab

Tipos:
- PAGE
- INTERNAL_URL
- EXTERNAL_URL

Regra:
- máximo de 2 níveis.

## 35. Redirect
Preserva SEO e links antigos quando slugs mudarem.

Campos:
- id
- sourcePath
- targetPath
- statusCode
- createdAt

Padrão:
- 301

## 36. SearchDocument
Índice unificado da busca.

Campos:
- entityType
- entityId
- institutionIds
- title
- content
- keywords
- url
- publishedAt

Tipos:
- PAGE
- ARTICLE
- COURSE
- EVENT
- CONTEST
- SELECTION_PROCESS
- DOCUMENT

## 37. SearchQueryLog
Estatísticas da busca interna.

Campos:
- id
- query
- resultsCount
- institutionFilter?
- typeFilter?
- createdAt

## 38. AnalyticsEvent
Modelo conceitual para estatísticas de acesso.

Campos:
- eventType
- path
- entityType?
- entityId?
- institutionId?
- timestamp

Eventos:
- PAGE_VIEW
- SEARCH
- DOWNLOAD
- EXTERNAL_LINK_CLICK
- COURSE_VIEW
- ARTICLE_VIEW
- EVENT_VIEW

## 39. SeoMetadata
Conceito reutilizável.

Campos:
- title
- description
- image
- canonicalUrl?
- noIndex

Aplicável a:
- Page
- Article
- Course
- Event

## 40. AccessibilityMetadata
Campos:
- altText
- isDecorative
- caption?

Regra:
- se isDecorative = false, altText é obrigatório
- se decorativa, usar alt=""

## 41. Publishable
Comportamento comum de publicação.

Campos:
- status
- publishedAt
- scheduledAt
- expiresAt
- publishedBy

Aplicável principalmente a:
- Page
- Article
- Event

## 42. AuditLog
Registra ações administrativas.

Campos:
- id
- userId
- action
- entityType
- entityId
- metadata
- ipAddress?
- createdAt

Exemplos:
- ARTICLE_CREATED
- ARTICLE_DELETED
- PAGE_UPDATED
- USER_CREATED
- MEDIA_UPLOADED
- MEDIA_DELETED
- MENU_CHANGED

## 43. ExternalSystem
Sistemas integrados.

Campos:
- id
- name
- type
- baseUrl
- isActive
- configuration

Inicialmente:
- PROCESSO_SELETIVO
- CONCURSOS

## 44. SelectionProcess
Dados vindos do sistema externo.

Campos conceituais:
- externalId
- institutionId
- title
- number
- year
- status
- registrationStart
- registrationEnd
- url

## 45. Contest
Dados vindos do sistema externo.

Campos conceituais:
- externalId
- institutionId
- title
- number
- year
- status
- startDate?
- endDate?
- url

## 46. SiteSetting
Configurações globais.

Campos:
- key
- value

Exemplos:
- siteName
- defaultSeoImage
- analyticsEnabled
- darkModeEnabled
- vLibrasEnabled

## 47. InstitutionSetting
Campos:
- institutionId
- contactEmail?
- phone?
- address?
- socialLinks?
- defaultSeoTitle?
- defaultSeoDescription?

## 48. Theme
Campos:
- institutionId
- logoLight
- logoDark
- primaryColor
- secondaryColor
- accentColor

Pode ser incorporado a Institution na implementação final.

---

# RELACIONAMENTOS PRINCIPAIS

Institution
├── UserInstitution ── User
├── Page
│   ├── PageBlock
│   └── PageVersion
├── ArticleInstitution ── Article
│                          ├── ArticleVersion
│                          ├── Categories
│                          └── Tags
├── Course
│   ├── CourseOffering
│   ├── CourseCurriculum
│   ├── CourseImage
│   └── CourseDocument
├── EventInstitution ── Event
│                        └── EventSchedule
├── Gallery
│   └── GalleryItem
├── Media
│   ├── MediaVariant
│   └── MediaUsage
├── InternshipArea
│   ├── InternshipCategory
│   └── InternshipDocument
└── Menu
    └── MenuItem

---

# NÚCLEO MÍNIMO DO SISTEMA

Primeira camada:
- Institution
- User
- UserInstitution
- Page
- PageBlock
- PageVersion
- PageTemplate
- Article
- ArticleInstitution
- ArticleVersion
- Category
- Tag
- Media
- MediaCategory
- MediaVariant
- MediaUsage

Segunda camada:
- Course
- CourseOffering
- Event
- EventSchedule
- Gallery
- Internship
- Search
- Analytics
- External integrations

---

# ESTRATÉGIA DE CONTEÚDO EM BLOCOS

Recomendação:
- Página: todos os blocos disponíveis
- Notícia: subconjunto controlado de blocos

Blocos possíveis em notícias:
- Texto
- Imagem
- Imagem + texto
- Carrossel
- Vídeo
- Documento
- CTA
- Tabela

Blocos dinâmicos como cursos automáticos e notícias automáticas não seriam usados dentro de uma notícia.

Uma modelagem possível:
- ContentBlock
  - id
  - ownerType
  - ownerId
  - type
  - position
  - configuration

ownerType:
- PAGE
- ARTICLE

A decisão final entre PageBlock específico ou ContentBlock genérico fica para a etapa de escolha de banco e ORM.

---

# SKIP LINK — REQUISITO TÉCNICO

Implementar skip link invisível até receber foco via teclado.

Exemplo:

```html
<a href="#main-content" class="skip-link">
  Ir para o conteúdo principal
</a>

<main id="main-content">
  ...
</main>
```

Comportamento:
- estado normal: invisível
- ao receber foco com TAB: fica visível
- ENTER: leva ao conteúdo principal

---

# PRÓXIMA ETAPA

Transformar este modelo conceitual em Modelo de Dados Lógico, definindo para cada entidade:

- campo
- tipo
- obrigatório/opcional
- unicidade
- índices
- chaves estrangeiras
- regras de exclusão
- relações 1:1
- relações 1:N
- relações N:N
